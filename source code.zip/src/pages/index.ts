import LoginPage from "./login-page";
import Home from "./home";

export { LoginPage, Home };
