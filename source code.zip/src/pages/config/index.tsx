import React from "react";
const Config = () => {
  <>config菜单配置页</>;
};
export default Config;
